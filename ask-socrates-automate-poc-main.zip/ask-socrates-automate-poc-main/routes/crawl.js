import express from 'express';
import { startCrawl } from '../crawl.js';
const router = express.Router();
const email = process.env.EMAIL;
const pass = process.env.PASSWORD;

console.log("init username ", email);
console.log("init pass ", pass);
/* GET home page. */
router.get('/', async (req, res) => {
  const crawlData = await startCrawl(email, pass);
  return res.json(crawlData);
});

export default router;
