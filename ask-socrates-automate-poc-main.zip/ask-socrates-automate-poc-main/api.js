import fetch from 'node-fetch';
const browserStaticInfo = {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7",
    "sec-ch-ua": "\"Google Chrome\";v=\"93\", \" Not;A Brand\";v=\"99\", \"Chromium\";v=\"93\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Linux\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
};

export const GetDataArrayAsPortlet = (cookie) => {
    return fetch("https://www.ask-socrates.com/DataArray/GetDataArrayAsPortlet?researchItemId=56539237c7eb6e355878bf9e&analysisId=61737185cd03995cb4be3ac1&marketName=Gld%20Miners&timeFrame=Daily", {
        "headers": {
            ...browserStaticInfo,
            "x-requested-with": "XMLHttpRequest",
            "cookie": cookie,
        },
        "referrerPolicy": "no-referrer",
        "body": null,
        "method": "GET",
        "mode": "cors"
    });
}

export const GetReversalsAsPortlet = (cookie) => {
    return fetch("https://www.ask-socrates.com/Reversal/GetReversalsAsPortlet?researchItemId=56539237c7eb6e355878bf9e&analysisId=61737185cd03995cb4be3ac1&marketName=Gld%20Miners&timeFrame=Daily&decimalPlaces=2&startDate=10%2F07%2F2020%2005%3A00%3A00", {
        "headers": {
            ...browserStaticInfo,
            "x-requested-with": "XMLHttpRequest",
            "cookie": cookie,
        },
        "referrerPolicy": "no-referrer",
        "body": null,
        "method": "GET",
        "mode": "cors"
    });
}