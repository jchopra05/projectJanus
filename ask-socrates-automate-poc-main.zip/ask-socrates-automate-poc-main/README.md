# Ask socrate data crawler - POC

## How to run
```js
- npm install
- npm start
- visit http://localhost:3000/crawl and wait for data come back
```
