import fetch from 'node-fetch';
const browserStaticInfo = {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7",
    "sec-ch-ua": "\"Google Chrome\";v=\"93\", \" Not;A Brand\";v=\"99\", \"Chromium\";v=\"93\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Linux\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
};

export const GetDataArrayAsPortlet = (cookie) => {
    return fetch("https://www.ask-socrates.com/DataArray/GetDataArrayAsPortlet?researchItemId=5d3fb56c54e8980c80bec1c4&analysisId=62f1cd1ecd03996428fa7e72&marketName=US - Nasdaq 100 E-mini&timeFrame=Daily", {
        "headers": {
            ...browserStaticInfo,
            "x-requested-with": "XMLHttpRequest",
            "cookie": cookie,
        },
        "referrerPolicy": "no-referrer",
        "body": null,
        "method": "GET",
        "mode": "cors"
    });
}

export const GetReversalsAsPortlet = (cookie) => {
    return fetch("https://www.ask-socrates.com/Market/GetSectionInfo?section=reversals", {
        "headers": {
            ...browserStaticInfo,
            "x-requested-with": "XMLHttpRequest",
            "cookie": cookie,
        },
        "referrerPolicy": "no-referrer",
        "body": null,
        "method": "GET",
        "mode": "cors"
    });
}