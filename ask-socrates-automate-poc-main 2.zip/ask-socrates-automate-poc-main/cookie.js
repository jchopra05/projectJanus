export const parseCookie = (jsonCookie) => {
    return jsonCookie.reduce((finalCookie, cookie) => {
        finalCookie += `${cookie.name}=${cookie.value}; `
        return finalCookie;
    }, "");
}
