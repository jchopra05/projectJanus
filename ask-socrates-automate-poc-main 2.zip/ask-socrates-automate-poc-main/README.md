# Ask socrate data crawler - POC

## How to run
```js
- npm install
- npm start
- visit http://localhost:3000/crawl and wait for data come back

```

## Add to Database 
- copy output into data.js line 16
- node data.js
- database URL: https://project-janus-db4a5-default-rtdb.asia-southeast1.firebasedatabase.app
