
// Include the chrome driver
import 'chromedriver';
import swd from 'selenium-webdriver';
const browser = new swd.Builder();
import { GetDataArrayAsPortlet, GetReversalsAsPortlet } from './api.js'
import { parseCookie } from './cookie.js';
import { parseArraysData, parseReversals } from './parseData.js';

export async function startCrawl(email, pass) {
    if (!email || !pass) {
        console.log("Email and password is missing");
        return;
    }

    console.log("Starting automate login process ...");
    const tab = browser.forBrowser("chrome").build();
    await tab.get("https://www.ask-socrates.com/Account/Login");
    await tab.manage().setTimeouts({
        implicit: 10000,
    });

    const promiseUsernameBox = await tab.findElement(swd.By.css("#EmailAddress"));
    promiseUsernameBox.sendKeys(email);

    const promisePasswordBox = await tab.findElement(swd.By.css("#Password"));
    promisePasswordBox.sendKeys(pass);

    const promiseSignInBtn = await tab.findElement(
        swd.By.css("#btnLoginButton")
    );

    await promiseSignInBtn.click();

    const cookies = await tab.manage().getCookies();
    const arrayDataAsPortlet = await GetDataArrayAsPortlet(parseCookie(cookies));
    const arrayDataResponse = await arrayDataAsPortlet.json();
    const arrayDataResult = parseArraysData(arrayDataResponse.htmlResult);
    console.log("Array " , arrayDataResult);

    const reversalAsPorletData = await GetReversalsAsPortlet(parseCookie(cookies));
    const reversalResponse = await reversalAsPorletData.json();
    const reversalResult = parseReversals(reversalResponse.htmlResult);
    console.log("Reversals ", reversalResult);

    tab.close();
    return {
        arrayDataResult: arrayDataResult,
        reversalResult: reversalResult
    }
}
